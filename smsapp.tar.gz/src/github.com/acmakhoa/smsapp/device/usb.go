package device

import(
	//"time"
	//"github.com/haxpax/goserial"	
)

func CanOpenPort(port string) bool{
		_ =port	
		return true
		// c := &serial.Config{Name: port, Baud: 115200, ReadTimeout: time.Second}
		// _, err := serial.OpenPort(c)
		// if err == nil {
		// 	return true
		// }			
		// return false	
}