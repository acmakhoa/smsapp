THIS PACKAGE IS DEPRECATED BUT RETAINED FOR COMPATIBILITY.

Please use github.com/tarm/serial for future projects.

It is 99.9% compatible (it returns a concrete *Port instead of an
io.ReadWriteCloser interface) while allowing room for future
expansion.  Please update your projects when you have the chance.
